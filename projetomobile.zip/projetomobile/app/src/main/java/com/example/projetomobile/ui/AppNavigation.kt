package com.example.projetomobile.ui

import android.util.Log
import androidx.compose.runtime.*
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.projetomobile.ui.screens.Appointment
import com.example.projetomobile.ui.screens.MainScreen
import com.example.projetomobile.ui.screens.ReminderScreen
import com.example.projetomobile.ui.screens.WelcomeScreen
import com.google.firebase.Timestamp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.delay

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val auth = Firebase.auth
    val db = Firebase.firestore

    var futureAppointments by remember { mutableStateOf<List<Appointment>?>(null) }
    var pastAppointments by remember { mutableStateOf<List<Appointment>?>(null) }
    var allAppointments by remember { mutableStateOf<List<Appointment>>(emptyList()) }
    var userName by remember { mutableStateOf("") }
    var ticker by remember { mutableStateOf(0) }

    // Helper para processar a lista de agendamentos
    fun processAppointments(appointments: List<Appointment>) {
        val now = Timestamp.now()
        val (past, future) = appointments.partition { (it.dateTime ?: now) < now }
        futureAppointments = future.sortedBy { it.dateTime }
        pastAppointments = past.sortedByDescending { it.dateTime }
    }

    // EFEITO 1: Ticker para reavaliar as listas a cada minuto
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000) // espera um minuto
            ticker++
        }
    }

    // EFEITO 2: Observa o estado de autenticação e busca os dados do Firebase
    DisposableEffect(auth.currentUser) {
        val user = auth.currentUser
        val listenerRegistration = if (user != null) {
            futureAppointments = null
            pastAppointments = null
            userName = ""

            db.collection("users").document(user.uid).get()
                .addOnSuccessListener { document ->
                    if (document != null && document.exists()) {
                        userName = document.getString("name") ?: ""
                    }
                }

            db.collection("appointments")
                .whereEqualTo("userId", user.uid)
                .addSnapshotListener { snapshots, e ->
                    if (e != null) {
                        Log.w("AppNavigation", "Listen failed.", e)
                        allAppointments = emptyList()
                        processAppointments(emptyList()) // Finaliza o carregamento com erro
                        return@addSnapshotListener
                    }
                    if (snapshots != null) {
                        val newAppointments = snapshots.documents.mapNotNull { document ->
                            document.toObject<Appointment>()?.copy(id = document.id)
                        }
                        allAppointments = newAppointments
                        // PROCESSAMENTO IMEDIATO DOS DADOS AO CHEGAREM
                        processAppointments(newAppointments)
                        Log.d("AppNavigation", "Loaded and processed ${allAppointments.size} appointments.")
                    }
                }
        } else {
            allAppointments = emptyList()
            userName = ""
            futureAppointments = emptyList()
            pastAppointments = emptyList()
            null
        }

        onDispose {
            listenerRegistration?.remove()
        }
    }

    // EFEITO 3: Roda apenas quando o ticker muda para reprocessar a lista JÁ CARREGADA
    LaunchedEffect(ticker) {
        if (ticker > 0) { // Não executa na primeira composição, apenas nos ticks do relógio
            Log.d("AppNavigation", "Ticker fired, reprocessing appointments.")
            processAppointments(allAppointments)
        }
    }

    val onAddAppointment: (Appointment) -> Unit = { newAppointment ->
        auth.currentUser?.uid?.let {
            db.collection("appointments").add(newAppointment.copy(userId = it))
        }
        navController.popBackStack()
    }

    val onDeleteAppointment: (Appointment) -> Unit = { appointment ->
        db.collection("appointments").document(appointment.id).delete()
    }

    val onUpdateAppointment: (Appointment) -> Unit = { updatedAppointment ->
        db.collection("appointments").document(updatedAppointment.id).set(updatedAppointment)
        navController.popBackStack()
    }

    val onEditAppointment: (Appointment) -> Unit = { appointment ->
        navController.navigate("reminder/${appointment.id}")
    }

    val onLogout: () -> Unit = {
        auth.signOut()
        navController.navigate("welcome") {
            popUpTo(navController.graph.startDestinationId) { inclusive = true }
        }
    }

    val startDestination = if (auth.currentUser != null) "main" else "welcome"

    NavHost(navController = navController, startDestination = startDestination) {
        composable("welcome") {
            WelcomeScreen(navController = navController)
        }

        composable("main") {
            MainScreen(
                navController = navController,
                userName = userName,
                futureAppointments = futureAppointments,
                pastAppointments = pastAppointments,
                onDeleteAppointment = onDeleteAppointment,
                onEditAppointment = onEditAppointment,
                onLogout = onLogout
            )
        }

        composable("reminder") {
            ReminderScreen(
                navController = navController,
                onSaveAppointment = onAddAppointment,
                appointmentToEdit = null
            )
        }

        composable(
            route = "reminder/{appointmentId}",
            arguments = listOf(navArgument("appointmentId") { type = NavType.StringType })
        ) { backStackEntry ->
            val appointmentId = backStackEntry.arguments?.getString("appointmentId")
            val appointmentToEdit = allAppointments.firstOrNull { it.id == appointmentId }

            ReminderScreen(
                navController = navController,
                onSaveAppointment = onUpdateAppointment,
                appointmentToEdit = appointmentToEdit
            )
        }
    }
}
