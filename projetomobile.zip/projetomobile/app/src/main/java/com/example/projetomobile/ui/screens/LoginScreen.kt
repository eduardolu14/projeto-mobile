package com.example.projetomobile.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.projetomobile.R
import com.example.projetomobile.ui.theme.ProjetomobileTheme
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WelcomeScreen(modifier: Modifier = Modifier, navController: NavController) {
    val sheetState = rememberModalBottomSheetState()
    val scope = rememberCoroutineScope()
    var showBottomSheet by remember { mutableStateOf(false) }
    var isLogin by remember { mutableStateOf(true) }

    val onAuthSuccess: () -> Unit = {
        scope.launch {
            sheetState.hide()
        }.invokeOnCompletion {
            if (!sheetState.isVisible) {
                showBottomSheet = false
                navController.navigate("main") { popUpTo("welcome") { inclusive = true } }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.minha_nova_logo),
            contentDescription = "Health Care Logo",
            modifier = Modifier.height(180.dp)
        )

        Spacer(modifier = Modifier.height(64.dp))

        Button(
            onClick = {
                isLogin = true
                showBottomSheet = true
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Entrar")
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(
            onClick = {
                isLogin = false
                showBottomSheet = true
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Cadastre-se")
        }
    }

    if (showBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = { showBottomSheet = false },
            sheetState = sheetState,
            modifier = Modifier.fillMaxHeight(0.7f),
            containerColor = MaterialTheme.colorScheme.primary
        ) {
            AuthSheetContent(
                isLogin = isLogin,
                onToggle = { isLogin = !isLogin },
                onAuthSuccess = onAuthSuccess
            )
        }
    }
}

@Composable
private fun AuthSheetContent(isLogin: Boolean, onToggle: () -> Unit, onAuthSuccess: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnimatedContent(targetState = isLogin, label = "auth_form") { isLoginTarget ->
            if (isLoginTarget) {
                LoginForm(onSignUpClick = onToggle, onLoginSuccess = onAuthSuccess)
            } else {
                SignUpForm(onLoginClick = onToggle, onSignUpSuccess = onAuthSuccess)
            }
        }
    }
}

@Composable
private fun LoginForm(onSignUpClick: () -> Unit, onLoginSuccess: () -> Unit) {
    val auth = Firebase.auth
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val performLogin: () -> Unit = {
        if (email.isBlank() || password.isBlank()) {
            errorMessage = "E-mail e senha são obrigatórios."
        } else {
            isLoading = true
            auth.signInWithEmailAndPassword(email.trim(), password.trim())
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        onLoginSuccess()
                    } else {
                        errorMessage = translateFirebaseException(task.exception)
                    }
                    isLoading = false
                }
        }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Login", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Spacer(modifier = Modifier.height(16.dp))

        errorMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
        }

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; errorMessage = null },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth(),
            colors = authTextFieldColors(),
            isError = errorMessage != null,
            enabled = !isLoading,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; errorMessage = null },
            label = { Text("Senha") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            colors = authTextFieldColors(),
            isError = errorMessage != null,
            enabled = !isLoading,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { performLogin() }),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = performLogin,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = MaterialTheme.colorScheme.primary),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.primary)
            } else {
                Text(text = "Entrar")
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        TextButton(onClick = onSignUpClick, enabled = !isLoading) {
            Text("Não tem uma conta? Cadastre-se", color = Color.White, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun SignUpForm(onLoginClick: () -> Unit, onSignUpSuccess: () -> Unit) {
    val context = LocalContext.current
    val auth = Firebase.auth
    val db = Firebase.firestore
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val performSignUp: () -> Unit = {
        if (name.isBlank() || email.isBlank() || password.isBlank()) {
            errorMessage = "Todos os campos são obrigatórios."
        } else {
            isLoading = true
            auth.createUserWithEmailAndPassword(email.trim(), password.trim())
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val user = auth.currentUser
                        if (user != null) {
                            val userData = hashMapOf("name" to name.trim())
                            db.collection("users").document(user.uid)
                                .set(userData)
                                .addOnSuccessListener {
                                    Toast.makeText(context, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show()
                                    onSignUpSuccess()
                                }
                                .addOnFailureListener { e ->
                                    errorMessage = "Erro ao salvar os dados do usuário."
                                    isLoading = false
                                }
                        } else {
                            errorMessage = "Erro: usuário não encontrado após criação."
                            isLoading = false
                        }
                    } else {
                        errorMessage = translateFirebaseException(task.exception)
                        isLoading = false
                    }
                }
        }
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Cadastro", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Spacer(modifier = Modifier.height(16.dp))

        errorMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
        }

        OutlinedTextField(
            value = name,
            onValueChange = { name = it; errorMessage = null },
            label = { Text("Nome") },
            modifier = Modifier.fillMaxWidth(),
            colors = authTextFieldColors(),
            isError = errorMessage != null,
            enabled = !isLoading,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; errorMessage = null },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth(),
            colors = authTextFieldColors(),
            isError = errorMessage != null,
            enabled = !isLoading,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; errorMessage = null },
            label = { Text("Senha") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            colors = authTextFieldColors(),
            isError = errorMessage != null,
            enabled = !isLoading,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { performSignUp() }),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = performSignUp,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = MaterialTheme.colorScheme.primary),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.primary)
            } else {
                Text(text = "Cadastrar")
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        TextButton(onClick = onLoginClick, enabled = !isLoading) {
            Text("Já possui cadastro? Entre aqui", color = Color.White, textAlign = TextAlign.Center)
        }
    }
}

private fun translateFirebaseException(exception: Exception?): String {
    val defaultError = "Ocorreu um erro. Tente novamente mais tarde."
    if (exception == null) return defaultError

    return when (exception) {
        is FirebaseAuthInvalidUserException -> "Não há conta registrada com este e-mail."
        is FirebaseAuthInvalidCredentialsException -> "Senha incorreta. Por favor, tente novamente."
        is FirebaseAuthUserCollisionException -> "Este e-mail já está cadastrado em outra conta."
        is FirebaseAuthWeakPasswordException -> "A senha é muito fraca. Ela deve ter no mínimo 6 caracteres."
        else -> {
            val message = exception.message ?: return defaultError
            when {
                message.contains("badly formatted") -> "O formato do e-mail é inválido."
                message.contains("network error") -> "Erro de conexão. Verifique sua internet."
                else -> defaultError
            }
        }
    }
}

@Composable
private fun authTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Color.White,
    unfocusedBorderColor = Color.White.copy(alpha = 0.7f),
    focusedLabelColor = Color.White,
    unfocusedLabelColor = Color.White.copy(alpha = 0.7f),
    cursorColor = Color.White,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    errorBorderColor = MaterialTheme.colorScheme.error,
    errorLabelColor = MaterialTheme.colorScheme.error
)


@Preview(showBackground = true)
@Composable
fun WelcomeScreenPreview() {
    ProjetomobileTheme {
        WelcomeScreen(navController = rememberNavController())
    }
}
