package com.example.projetomobile.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

data class BottomNavItem(val route: String, val icon: ImageVector, val label: String)

@Composable
fun MainScreen(
    navController: NavController,
    userName: String,
    futureAppointments: List<Appointment>?,
    pastAppointments: List<Appointment>?,
    onDeleteAppointment: (Appointment) -> Unit,
    onEditAppointment: (Appointment) -> Unit,
    onLogout: () -> Unit
) {
    val bottomBarNavController = rememberNavController()
    val navBackStackEntry by bottomBarNavController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    Scaffold(
        containerColor = MaterialTheme.colorScheme.primary,
        bottomBar = {
            NavigationBar {
                val items = listOf(
                    BottomNavItem("home", Icons.Default.Home, "Home"),
                    BottomNavItem("history", Icons.Default.DateRange, "Histórico"),
                    BottomNavItem("profile", Icons.Default.Person, "Perfil")
                )

                items.forEach { item ->
                    NavigationBarItem(
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                        selected = currentDestination?.hierarchy?.any { it.route == item.route } == true,
                        onClick = {
                            bottomBarNavController.navigate(item.route) {
                                popUpTo(bottomBarNavController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        },
        floatingActionButton = {
            // O botão só aparece se a lista de futuros já tiver sido carregada (não é mais nula)
            if (currentDestination?.route == "home" && futureAppointments != null) {
                FloatingActionButton(onClick = { navController.navigate("reminder") }) {
                    Icon(Icons.Default.Add, contentDescription = "Adicionar Lembrete")
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = bottomBarNavController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") {
                HomeScreen(
                    navController = bottomBarNavController,
                    appointments = futureAppointments,
                    onDeleteAppointment = onDeleteAppointment,
                    onEditAppointment = onEditAppointment
                )
            }
            composable("history") {
                HistoryScreen(
                    navController = bottomBarNavController,
                    appointments = pastAppointments,
                    onDeleteAppointment = onDeleteAppointment,
                    onEditAppointment = onEditAppointment
                )
            }
            composable("profile") { ProfileScreen(navController = bottomBarNavController, userName = userName, onLogoutClick = onLogout) }
        }
    }
}
