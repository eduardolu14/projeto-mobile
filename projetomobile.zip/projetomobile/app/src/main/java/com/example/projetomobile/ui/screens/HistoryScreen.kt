package com.example.projetomobile.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.projetomobile.ui.theme.ProjetomobileTheme
import com.google.firebase.Timestamp

@Composable
fun HistoryScreen(
    modifier: Modifier = Modifier,
    navController: NavController,
    appointments: List<Appointment>?,
    onDeleteAppointment: (Appointment) -> Unit,
    onEditAppointment: (Appointment) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    Column(modifier = modifier.padding(16.dp)) {
        Text(text = "Histórico", style = MaterialTheme.typography.headlineMedium, color = Color.White)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Buscar no Histórico") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon") },
            modifier = Modifier.fillMaxWidth(),
            colors = homeScreenTextFieldColors()
        )

        Spacer(modifier = Modifier.height(16.dp))

        when {
            // Estado de Carregamento: a lista é nula
            appointments == null -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Carregando histórico...", color = Color.White)
                    }
                }
            }
            // Estado Vazio: a lista foi carregada, mas está vazia
            appointments.isEmpty() -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "Nenhum lembrete no histórico.",
                        color = Color.White.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                }
            }
            // Estado Carregado: a lista tem itens
            else -> {
                val filteredAppointments = if (searchQuery.isBlank()) {
                    appointments
                } else {
                    appointments.filter {
                        it.title.contains(searchQuery, ignoreCase = true)
                    }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filteredAppointments) { appointment ->
                        AppointmentItem(
                            appointment = appointment,
                            onDeleteClick = { onDeleteAppointment(appointment) },
                            onEditClick = { onEditAppointment(appointment) }
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HistoryScreenPreview() {
    ProjetomobileTheme {
        val sampleAppointments = listOf(
            Appointment(title = "Dr. Carlos Andrade", dateTime = Timestamp.now()),
            Appointment(title = "Dra. Beatriz Melo", dateTime = Timestamp.now()),
        )
        HistoryScreen(
            navController = rememberNavController(),
            appointments = sampleAppointments,
            onDeleteAppointment = {},
            onEditAppointment = {}
        )
    }
}
