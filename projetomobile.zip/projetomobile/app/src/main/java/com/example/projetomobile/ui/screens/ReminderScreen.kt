package com.example.projetomobile.ui.screens

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.projetomobile.ui.theme.ProjetomobileTheme
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderScreen(
    modifier: Modifier = Modifier,
    navController: NavController,
    onSaveAppointment: (Appointment) -> Unit,
    appointmentToEdit: Appointment? = null
) {
    val context = LocalContext.current

    var title by remember { mutableStateOf("") }
    var selectedDateMillis by remember { mutableStateOf<Long?>(null) }
    var selectedHour by remember { mutableStateOf<Int?>(null) }
    var selectedMinute by remember { mutableStateOf<Int?>(null) }

    val showDatePicker = remember { mutableStateOf(false) }
    val showTimePicker = remember { mutableStateOf(false) }

    val isEditing = appointmentToEdit != null

    LaunchedEffect(appointmentToEdit) {
        if (isEditing && appointmentToEdit?.dateTime != null) {
            title = appointmentToEdit.title
            val calendar = Calendar.getInstance().apply {
                time = appointmentToEdit.dateTime.toDate()
            }
            selectedDateMillis = calendar.timeInMillis
            selectedHour = calendar.get(Calendar.HOUR_OF_DAY)
            selectedMinute = calendar.get(Calendar.MINUTE)
        }
    }

    val formattedDate = remember(selectedDateMillis) {
        selectedDateMillis?.let {
            val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).apply {
                // O DatePicker retorna um timestamp em UTC. Para exibir a data correta
                // que o usuário selecionou, independentemente do fuso do aparelho,
                // formatamos a data tratando-a como UTC.
                timeZone = TimeZone.getTimeZone("UTC")
            }
            sdf.format(Date(it))
        } ?: ""
    }

    val formattedTime = remember(selectedHour, selectedMinute) {
        if (selectedHour != null && selectedMinute != null) {
            String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute)
        } else {
            ""
        }
    }

    Column(modifier = modifier.padding(16.dp)) {
        Text(text = if (isEditing) "Editar Lembrete" else "Adicionar Lembrete", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Título") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = formattedDate,
                onValueChange = { },
                label = { Text("Data") },
                modifier = Modifier
                    .weight(1f)
                    .clickable { showDatePicker.value = true },
                readOnly = true,
                enabled = false,
                colors = OutlinedTextFieldDefaults.colors(
                    disabledBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
                    disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
                    disabledTextColor = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            OutlinedTextField(
                value = formattedTime,
                onValueChange = { },
                label = { Text("Hora") },
                modifier = Modifier
                    .weight(1f)
                    .clickable { showTimePicker.value = true },
                readOnly = true,
                enabled = false,
                colors = OutlinedTextFieldDefaults.colors(
                    disabledBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
                    disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
                    disabledTextColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (title.isNotBlank() && formattedDate.isNotBlank() && formattedTime.isNotBlank()) {
                    // Combina a data e a hora da UI e interpreta usando o fuso horário padrão do dispositivo.
                    val dateTimeString = "$formattedDate $formattedTime"
                    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                    // O SimpleDateFormat já usa o fuso horário padrão do dispositivo por padrão.

                    try {
                        val date = sdf.parse(dateTimeString)
                        val finalTimestamp = Timestamp(date)

                        val appointment = if (isEditing) {
                            appointmentToEdit!!.copy(title = title, dateTime = finalTimestamp)
                        } else {
                            Appointment(title = title, dateTime = finalTimestamp)
                        }
                        onSaveAppointment(appointment)

                    } catch (e: Exception) {
                        Toast.makeText(context, "Erro ao processar data e hora.", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(context, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Salvar lembrete")
        }
    }

    if (showDatePicker.value) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = selectedDateMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker.value = false },
            confirmButton = {
                TextButton(onClick = {
                    selectedDateMillis = datePickerState.selectedDateMillis
                    showDatePicker.value = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker.value = false }) { Text("Cancelar") } }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    if (showTimePicker.value) {
        val initialHour = selectedHour ?: Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val initialMinute = selectedMinute ?: Calendar.getInstance().get(Calendar.MINUTE)
        val timePickerState = rememberTimePickerState(initialHour = initialHour, initialMinute = initialMinute)

        TimePickerDialog(
            onDismissRequest = { showTimePicker.value = false },
            confirmButton = {
                TextButton(onClick = {
                    selectedHour = timePickerState.hour
                    selectedMinute = timePickerState.minute
                    showTimePicker.value = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showTimePicker.value = false }) { Text("Cancelar") } }
        ) {
            TimePicker(state = timePickerState, modifier = Modifier.padding(16.dp))
        }
    }
}

// Custom TimePickerDialog Composable
@Composable
fun TimePickerDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    dismissButton: @Composable () -> Unit,
    content: @Composable () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = { Text(text = "Selecione a Hora") },
        text = { content() },
        confirmButton = confirmButton,
        dismissButton = dismissButton
    )
}


@Preview(showBackground = true)
@Composable
fun ReminderScreenPreview() {
    ProjetomobileTheme {
        ReminderScreen(navController = rememberNavController(), onSaveAppointment = {}, appointmentToEdit = null)
    }
}
