package com.example.projetomobile.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.projetomobile.ui.theme.ProjetomobileTheme
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

// Estrutura de dados para o Firestore com Timestamp
data class Appointment(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val dateTime: Timestamp? = null
)

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    navController: NavController,
    appointments: List<Appointment>?,
    onDeleteAppointment: (Appointment) -> Unit,
    onEditAppointment: (Appointment) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    Column(modifier = modifier.padding(16.dp)) {
        Text(text = "Futuras", style = MaterialTheme.typography.headlineMedium, color = Color.White)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Buscar") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon") },
            modifier = Modifier.fillMaxWidth(),
            colors = homeScreenTextFieldColors()
        )

        Spacer(modifier = Modifier.height(16.dp))

        when {
            // Estado de Carregamento: a lista é nula
            appointments == null -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color.White)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Carregando lembretes...", color = Color.White)
                    }
                }
            }
            // Estado Vazio: a lista foi carregada, mas está vazia
            appointments.isEmpty() -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "Nenhum lembrete futuro encontrado.\nToque no botão + para adicionar.",
                        color = Color.White.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                }
            }
            // Estado Carregado: a lista tem itens
            else -> {
                val filteredAppointments = if (searchQuery.isBlank()) {
                    appointments
                } else {
                    appointments.filter {
                        it.title.contains(searchQuery, ignoreCase = true)
                    }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filteredAppointments) { appointment ->
                        AppointmentItem(
                            appointment = appointment,
                            onDeleteClick = { onDeleteAppointment(appointment) },
                            onEditClick = { onEditAppointment(appointment) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppointmentItem(
    appointment: Appointment,
    onDeleteClick: () -> Unit,
    onEditClick: () -> Unit
) {
    // SOLUÇÃO DEFINITIVA PARA EXIBIÇÃO DO FUSO HORÁRIO
    val saoPauloTimeZone = TimeZone.getTimeZone("America/Sao_Paulo")

    val dateFormatter = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).apply {
        timeZone = saoPauloTimeZone
    }
    val timeFormatter = SimpleDateFormat("HH:mm", Locale.getDefault()).apply {
        timeZone = saoPauloTimeZone
    }

    val dateString = appointment.dateTime?.toDate()?.let { dateFormatter.format(it) } ?: ""
    val timeString = appointment.dateTime?.toDate()?.let { timeFormatter.format(it) } ?: ""

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 16.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = appointment.title, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "Data: $dateString", style = MaterialTheme.typography.bodyMedium)
                Text(text = "Hora: $timeString", style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = onEditClick) {
                Icon(Icons.Default.Edit, contentDescription = "Editar")
            }
            IconButton(onClick = onDeleteClick) {
                Icon(Icons.Default.Delete, contentDescription = "Excluir")
            }
        }
    }
}

@Composable
internal fun homeScreenTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Color.White,
    unfocusedBorderColor = Color.White.copy(alpha = 0.7f),
    focusedLabelColor = Color.White,
    unfocusedLabelColor = Color.White.copy(alpha = 0.7f),
    cursorColor = Color.White,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedLeadingIconColor = Color.White,
    unfocusedLeadingIconColor = Color.White.copy(alpha = 0.7f)
)

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    ProjetomobileTheme {
        val sampleAppointments = listOf(
            Appointment(title = "Cardiologista", dateTime = Timestamp.now()),
            Appointment(title = "Dermatologista", dateTime = Timestamp.now()),
        )
        HomeScreen(
            navController = rememberNavController(),
            appointments = sampleAppointments,
            onDeleteAppointment = {},
            onEditAppointment = {}
        )
    }
}
